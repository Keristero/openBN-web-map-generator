<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="ground_feature" tilewidth="64" tileheight="32" tilecount="1" columns="1">
 <image source="ground_feature.png" width="64" height="32"/>
</tileset>
