<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="back-stairs" tilewidth="92" tileheight="40" tilecount="3" columns="1">
 <tileoffset x="-16" y="8"/>
 <properties>
  <property name="Direction" value="Down Left"/>
 </properties>
 <image source="back-stairs.png" width="92" height="120"/>
 <tile id="0" type="Stairs"/>
 <tile id="1" type="Stairs"/>
 <tile id="2" type="Stairs"/>
</tileset>
