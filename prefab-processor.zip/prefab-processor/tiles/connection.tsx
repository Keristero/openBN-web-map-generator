<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.02.15" name="connection" tilewidth="64" tileheight="32" tilecount="1" columns="1">
 <image source="connection.png" width="64" height="32"/>
</tileset>
