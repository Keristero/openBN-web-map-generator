<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.02.15" name="wall_feature" tilewidth="64" tileheight="64" tilecount="1" columns="1" objectalignment="bottom">
 <transformations hflip="1" vflip="0" rotate="0" preferuntransformed="0"/>
 <image source="wall_feature.png" width="64" height="64"/>
</tileset>
