<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="prefab_tiles" tilewidth="64" tileheight="40" tilecount="4" columns="4">
 <tileoffset x="0" y="8"/>
 <image source="prefab_tiles.png" width="256" height="40"/>
</tileset>
