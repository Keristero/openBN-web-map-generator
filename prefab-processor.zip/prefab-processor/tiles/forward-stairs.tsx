<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="forward-stairs" tilewidth="63" tileheight="55" tilecount="2" columns="2">
 <tileoffset x="0" y="7"/>
 <image source="forward-stairs.png" width="126" height="55"/>
 <tile id="0" type="Stairs">
  <properties>
   <property name="Direction" value="Up Left"/>
  </properties>
 </tile>
</tileset>
